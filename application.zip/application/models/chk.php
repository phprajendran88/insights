<?php
$con = mysqli_connect("replica.coiwhcgqtihv.ap-south-1.rds.amazonaws.com","ro","readonly","Livein3boonboxpilot");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }else
  {
	  
	  echo "connected";
  }
?>