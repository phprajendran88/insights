<?php 
$this->load->view('header');
$this->load->view('left-menu');
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Home
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Home</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" id="content">
		
		<div class="box box-danger" style="padding:10px 5px;">
			<div id="show_iframe" class="box-header with-border" id="Container"
			 style="padding-bottom:56.25%; position:relative; display:block; width: 100%">
			 <iframe id="ViostreamIframe" width="100%" height="100%"  src="https://app.powerbi.com/view?r=eyJrIjoiOTQ5OGYxNjMtODk1MC00YWFjLWEwNGUtMjdjNjYyZmUxYmQxIiwidCI6ImM0OWFjY2U4LTE0MTUtNDFiMy04NTkzLTM1ZmZjOTdhNWYxNiJ9" frameborder="0" allowfullscreen="true" style="position:absolute; top:0; left: 0"></iframe>
			</div>
			</div>
		<script src="https://microsoft.github.io/PowerBI-JavaScript/demo/bower_components/jquery/dist/jquery.js"></script>  
 <script src="https://microsoft.github.io/PowerBI-JavaScript/demo/bower_components/powerbi-client/dist/powerbi.js"></script>
 
    <script src="https://microsoft.github.io/PowerBI-JavaScript/demo/bower_components/es6-promise/es6-promise.js"></script>
    <script src="https://microsoft.github.io/PowerBI-JavaScript/demo/bower_components/fetch/fetch.js"></script>
     

<script type="text/javascript">
window.onload = function () {
 
var embedConfiguration = {
    type: 'report',
    accessToken: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ2ZXIiOiIwLjIuMCIsIndjbiI6Indya3NwY0NsbGN0bjRQQkkiLCJ3aWQiOiJiN2NmNDMzYi00MzdjLTRjYTUtOWRmMi1kOWZkODIxODI0NjEiLCJyaWQiOiI3MzQ1MDNjZi0xMzA5LTQ4OTItODU4Zi03OTFkNjJjMTU0YWQiLCJpc3MiOiJQb3dlckJJU0RLIiwiYXVkIjoiaHR0cHM6Ly9hbmFseXNpcy53aW5kb3dzLm5ldC9wb3dlcmJpL2FwaSIsImV4cCI6MTUxNDY0OTYwMCwibmJmIjoxNDgxNTI1MjQwfQ.5K18TRRyrbdn4eo5yAPkjvP5TCYg6MbnqimDt9TcxPA',
    id: '734503cf-1309-4892-858f-791d62c154ad',
    embedUrl: 'https://embedded.powerbi.com/appTokenReportEmbed?reportId=734503cf-1309-4892-858f-791d62c154ad' 
}; 

var $reportContainer = $('#reportContainer');
 
var report = powerbi.embed($reportContainer.get(0), embedConfiguration);
  
report.fullscreen();  

}
</script>

<div id="reportContainer"></div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php 
$this->load->view('footer');

?>


 
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?=base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?=base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- ChartJS -->
<script src="<?=base_url();?>assets/bower_components/chart.js/Chart.js"></script>
<!-- FastClick -->
<script src="<?=base_url();?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url();?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url();?>assets/dist/js/demo.js"></script>
<!-- page script -->
<script>
$('.content-wrapper').click (function () {
  //  alert($(this).height());
	//$("#content").css("width", $(this).height());
});

</script>
<script>
$(function(){
	
	navigator.getBattery().then(function(battery) {
    if (battery.charging && battery.chargingTime === 0) {
        
    } else {
      //  console.log("I'm not a desktop")
		
    }
});

if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
console.log("I'm not a desktop")
$("#show_iframe").html(' <iframe id="ViostreamIframe" width="100%" height="100%"  src="https://app.powerbi.com/view?r=eyJrIjoiMjFkM2I4YzQtYzNhMy00MzNkLTllZGItYjdjMzRmZTg1YzkzIiwidCI6ImM0OWFjY2U4LTE0MTUtNDFiMy04NTkzLTM1ZmZjOTdhNWYxNiJ9" frameborder="0" allowfullscreen="true" style="position:absolute; top:0; left: 0"></iframe>');
}else{
	console.log("I'm a desktop")
	$("#show_iframe").html('<iframe id="ViostreamIframe"  width="100%" height="100%" src="https://app.powerbi.com/view?r=eyJrIjoiOTQ5OGYxNjMtODk1MC00YWFjLWEwNGUtMjdjNjYyZmUxYmQxIiwidCI6ImM0OWFjY2U4LTE0MTUtNDFiMy04NTkzLTM1ZmZjOTdhNWYxNiJ9" frameborder="0" allowfullscreen="true" style="position:absolute; top:0; left: 0"></iframe>');
	
}
})

</script>
</body>
</html>
